INSERT INTO 
	TBL_EMPLOYEES (first_name, last_name, email) 
VALUES
  	('Amit', 'Kumar', 'amitkumar1211@gmail.com'),
  	('Alok', 'Kumar', 'alok@email.com'),
  	('Sumit', 'Kumar', 'sumit@email.com'),
  	('Gaurav', 'Kumar', 'gaurav@email.com'),
  	('Karthik', 'Kumar', 'karthik@email.com'),
  	('Gopal', 'Kumar', 'gopal@email.com'),
  	('Sohan', 'Kumar', 'sohan@email.com');