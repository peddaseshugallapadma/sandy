package com.olx.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.olx.demo.entity.Categories;

public interface CategoriesRepository extends JpaRepository<Categories, Integer>{

}
