package com.olx.demo.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import com.olx.demo.entity.AdvStatus;
import com.olx.demo.entity.Categories;
import com.olx.demo.service.OlxMasterdataService;

@RestController
@RequestMapping("/advertise")
public class OlxMasterdataController {
	@Autowired
	OlxMasterdataService olxmasterdataservice;

	@RequestMapping("/status")
	public List<AdvStatus> getAdvStatus() {
		olxmasterdataservice.addAdvertiseStatus();
		return olxmasterdataservice.getAllAdvStatus();
	}

	@RequestMapping("/category")
	public List<Categories> getCategories() {
		olxmasterdataservice.addCategories();
		return olxmasterdataservice.getAllCategories();
	}
}
