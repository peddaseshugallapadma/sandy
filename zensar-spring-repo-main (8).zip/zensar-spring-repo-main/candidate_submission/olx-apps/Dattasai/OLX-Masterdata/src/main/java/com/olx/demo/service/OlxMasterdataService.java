package com.olx.demo.service;

import java.util.List;

import com.olx.demo.entity.AdvStatus;
import com.olx.demo.entity.Categories;



public interface OlxMasterdataService {
	public List<AdvStatus> getAllAdvStatus();

	public List<Categories> getAllCategories();

	public void addAdvertiseStatus();

	public void addCategories();
}
