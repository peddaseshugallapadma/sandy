package com.olx.demo.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.olx.demo.entity.AdvStatus;

public interface AdvStatusRepository extends JpaRepository<AdvStatus, Integer>{

}
