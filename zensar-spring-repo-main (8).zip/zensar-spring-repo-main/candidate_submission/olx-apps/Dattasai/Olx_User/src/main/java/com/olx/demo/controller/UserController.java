package com.olx.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.olx.demo.entity.User;
import com.olx.demo.service.*;

@RestController
@RequestMapping("/user")
public class UserController {
     
	@Autowired
    UserService userservice;
	
	@PostMapping("/login")
	public  ResponseEntity<String> authentication(@RequestBody User user){
		return new ResponseEntity<>(userservice.authuntication(user),HttpStatus.ACCEPTED);
	}
	@PostMapping()
	public ResponseEntity<User> registration(@RequestBody User user){
		return new ResponseEntity<>(userservice.registration(user),HttpStatus.ACCEPTED);
	}
	@GetMapping()
	public ResponseEntity<List<User>> getUser(){
		return new ResponseEntity<>(userservice.userDetials(),HttpStatus.OK);
	}
	@DeleteMapping("/logout")
	public ResponseEntity<Boolean> deleteUser(@RequestBody User user){
		return new ResponseEntity<>(userservice.delete(user),HttpStatus.OK);
	}
}
