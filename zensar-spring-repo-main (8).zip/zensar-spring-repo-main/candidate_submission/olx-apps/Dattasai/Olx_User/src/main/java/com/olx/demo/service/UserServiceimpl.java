package com.olx.demo.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.olx.demo.entity.User;
import com.olx.demo.repo.UserRepository;

@Service
public class UserServiceimpl implements UserService {
      
	@Autowired
	 UserRepository userreprository;
	 
	@Override
	public String authuntication(User user) {
		// TODO Auto-generated method stub
		User usernamerepo=userreprository.findByUsernameAndPassword(user.getUsername(), user.getPassword());
		if(usernamerepo != null) {
			return "your successfully login";
		}else {
		return "Username and password are incorect"; 
		}
	}

	@Override
	public User registration(User user) {
		// TODO Auto-generated method stub
		return userreprository.save(user);
	}

	@Override
	public List<User> userDetials() {
		// TODO Auto-generated method stub
		return (List<User>) userreprository.findAll();
	}

	@Override
	public boolean delete(User user) {
		User usernamerepo=userreprository.findByUsernameAndPassword(user.getUsername(), user.getPassword());
		if(usernamerepo != null) {
			userreprository.delete(usernamerepo);
			return true;
		}
		return false;
	}

}
