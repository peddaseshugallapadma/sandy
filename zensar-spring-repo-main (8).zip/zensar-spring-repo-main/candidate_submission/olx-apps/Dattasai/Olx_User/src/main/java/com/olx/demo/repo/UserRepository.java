package com.olx.demo.repo;


import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.olx.demo.entity.User;

@Repository
public interface UserRepository extends CrudRepository<User, Integer> {

	
      User findByUsernameAndPassword(String username,String password);

	

}
