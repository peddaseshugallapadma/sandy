package com.Ramu.olx.repository;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import com.Ramu.olx.model.User; 
public interface UserRepository extends JpaRepository<User,Integer>{
User findUserByUsernameAndPassword(String username, String password);
}


