package com.aisha.olx.web;

	import java.util.List;



	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.http.HttpStatus;
	import org.springframework.http.ResponseEntity;
	import org.springframework.web.bind.annotation.GetMapping;
	import org.springframework.web.bind.annotation.PathVariable;
	import org.springframework.web.bind.annotation.PostMapping;
	import org.springframework.web.bind.annotation.RequestBody;
	import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;



	import com.aisha.olx.model.User;
	import com.aisha.olx.service.UserService;



	@RestController
	@RequestMapping("/users")
	public class UserController {



	@Autowired
	private UserService uService;



	@PostMapping
	public ResponseEntity<User>Registration(@RequestBody User u){
	return new ResponseEntity<>(uService.Registration(u), HttpStatus.CREATED);
	}



	@GetMapping
	public ResponseEntity<List<User>> getAllUser(){
	return new ResponseEntity<>(uService.fetchAllUser(),HttpStatus.OK);
	}



	/*
	@DeleteMapping("/{uid}")
	public ResponseEntity<User> deleteUser(@PathVariable Integer uid){
	return new ResponseEntity<>(uService.deleteUser(uid) , HttpStatus.ACCEPTED);
	}



	@PostMapping
	public ResponseEntity<User> loginUser(@RequestBody String n,String pass,User u){
	return new ResponseEntity<>(uService.loginUser(n,pass,u), HttpStatus.CREATED);
	}
	*/
	
	@PostMapping("/login")
	public  ResponseEntity<String> login(@RequestBody User u)
	{
		return new ResponseEntity<>(uService.login(u),HttpStatus.ACCEPTED);
	}
	
	@RequestMapping(value="/delete/{id}",method=RequestMethod.DELETE)
	@ResponseBody
	public String deleteById(@PathVariable Integer uid)
	{
		uService.deleteById(uid);
		return "Successfully Deleted";
	}
	}
	
	/*
	@PostMapping()
	public ResponseEntity<User> registration(@RequestBody User user){
		return new ResponseEntity<>(userservice.registration(user),HttpStatus.ACCEPTED);
	}
	@GetMapping()
	public ResponseEntity<List<User>> getUser(){
		return new ResponseEntity<>(userservice.userDetials(),HttpStatus.OK);
	}
	@DeleteMapping("/logout")
	public ResponseEntity<Boolean> deleteUser(@RequestBody User user){
		return new ResponseEntity<>(userservice.delete(user),HttpStatus.OK);
	} */
	

