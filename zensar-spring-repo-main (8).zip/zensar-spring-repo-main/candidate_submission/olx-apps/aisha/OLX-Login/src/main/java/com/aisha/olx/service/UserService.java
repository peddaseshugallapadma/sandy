package com.aisha.olx.service;

	import java.util.List;



	import com.aisha.olx.model.User;



	public interface UserService {

	public User Registration(User u);
	public List<User> fetchAllUser();
	//public Integer deleteUser(Integer uid);
	//public User loginUser(String uname,String pass,User u );
	public String login(User u);
	public void deleteById(Integer uid);
	
	}

