package com.aisha.olx.repository;

	import org.springframework.data.jpa.repository.JpaRepository;

	import java.util.List;

	import org.springframework.data.jpa.repository.JpaRepository;

	import com.aisha.olx.model.User;

	public interface UserRepository extends JpaRepository<User,Integer>{

		User findByUnameAndPassword(String uname,String password);

	}
