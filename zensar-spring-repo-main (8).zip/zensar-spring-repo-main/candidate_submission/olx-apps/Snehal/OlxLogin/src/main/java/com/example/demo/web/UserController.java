package com.example.demo.web;

import java.util.List;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.User;
import com.example.demo.service.UserService;

@RestController
@RequestMapping
public class UserController {

	@Autowired
	private UserService userService;
	
	@PostMapping("/user")
	public ResponseEntity<User> addUser(@RequestBody User user)
	{
		return new ResponseEntity<>(userService.addUser(user), HttpStatus.CREATED);
	}
	
	@PostMapping("/authenticate")
	public ResponseEntity<String> AuthenticateUserDetail(@RequestBody User userAuthenticate)
	{
		return new ResponseEntity<>(userService.AuthenticateUser(userAuthenticate), HttpStatus.OK);
	} 
	
	
	@GetMapping("/user")
	public ResponseEntity<User> showUserDetail(@RequestBody User finduser)
	{
		return new ResponseEntity<>(userService.getUserDetail(finduser), HttpStatus.CREATED);
	}
	 
	
	@DeleteMapping("/logout")
	public ResponseEntity<String> logoutUser(@RequestBody User logDetail)
	{
		return new ResponseEntity<>(userService.getLogOutDetail(logDetail), HttpStatus.CREATED);
	}
	 
	
}
	
	

