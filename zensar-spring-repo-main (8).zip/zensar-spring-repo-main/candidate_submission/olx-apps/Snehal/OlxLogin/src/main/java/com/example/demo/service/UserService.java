package com.example.demo.service;

import com.example.demo.model.User;

public interface UserService 
{

	public User addUser(User user);

	public String AuthenticateUser(User userDetails);
	
	public User getUserDetail(User findUser);
	
	public String getLogOutDetail(User logDetail);
	
		
	
}

