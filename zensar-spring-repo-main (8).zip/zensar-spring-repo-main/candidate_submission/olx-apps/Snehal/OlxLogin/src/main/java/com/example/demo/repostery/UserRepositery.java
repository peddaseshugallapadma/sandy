package com.example.demo.repostery;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.model.User;

public interface UserRepositery extends JpaRepository<User, Integer>
{

}
