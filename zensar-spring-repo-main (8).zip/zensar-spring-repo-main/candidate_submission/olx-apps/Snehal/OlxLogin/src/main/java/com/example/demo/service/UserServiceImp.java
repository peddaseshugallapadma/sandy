package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.User;
import com.example.demo.repostery.UserRepositery;

@Service
public class UserServiceImp implements UserService {

	@Autowired
	private UserRepositery userRepositery;
	
	@Override
	public User addUser(User user)
	{
		return userRepositery.save(user);

	}

	@Override
	public String AuthenticateUser(User userDetails) 
	{
    List<User> userList=new ArrayList<User>();
    boolean flag=false;
    userList=userRepositery.findAll();
    
    for(User userObject:userList)
    {
    	
    	if((userObject.getUserName().equals(userDetails.getUserName())) && (userObject.getPassword().equals(userDetails.getPassword())))
    	{
    		flag=true;
    		break;
    	}
    }
    
    if(flag==true)
    {
    	return "auth-token";
    }
    else
    {
    	return "not authicated";
    }
		
	}

	@Override
	public User getUserDetail(User findUser) {
		User tempUser=null;
		 List<User> userList=new ArrayList<User>();
		  userList=userRepositery.findAll();
		
		  for(User data:userList)
		  {
			  if(findUser.getUserName().equals(data.getUserName()) && findUser.getPassword().equals(data.getPassword()))
			  {
				  tempUser=data;
				  break;
			  }
		  }
		
		return tempUser;
	}

	@Override
	public String getLogOutDetail(User logDetail) {
    
	    User tempUser=null;
	    
		 List<User> userList=new ArrayList<User>();
		  userList=userRepositery.findAll();
		boolean flag=false;
		  for(User data:userList)
		  {
			  if(data.getUserName().equals(logDetail.getUserName()) && data.getPassword().equals(logDetail.getPassword()))
			  {
				  tempUser=data;
				  userRepositery.delete(tempUser);;
				  flag=true;
				  break;
				  
			  }
		  }
		
		
		
		if(flag==true)
		{
			return "true";
		}
		else
		{
			return "false";
		}
	}
	
	
	
	

}
