package com.example.demo.domain;

public enum ActiveEnum 
{

TRUE,
FALSE;
	
	
}
