package com.example.demo.service;

import java.util.List;

import com.example.demo.model.User;



public interface OlxService {
	
	   public List<User> getAllUsers();

	   //public User createUser (Long id);

	public String loginUser(String username , String password);
	
	public User registerUser(User user);
	
	public User getUser(Long id);
	
	public boolean logoutUser(int id);

	
		
	

	   
	  

	   
}


