package com.example.demo.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.demo.model.User;
import com.example.demo.repository.UserRepository;

@Service
public class OlxServiceImpl implements OlxService {
	@Autowired
	UserRepository userRepository;

	  Map<Integer,User> userList=new HashMap<>();
	  

		public List<User> getAllUsers() {
			List<User> userslist =new ArrayList<>();
			   for(User u : userList.values()) {
				   userslist.add(u);
			   }
			return userslist;

}
/*@Override
public User createUser(Long id) {
	return userRepository.save(id);
}*/
@Override
public String loginUser(String username, String password) {
	User user = userRepository.findUserByUsernameAndPassword(username, password);
	if(user !=null) {
		return username;	
	}
	else
	{
		return null;
	}
}
@Override
public boolean logoutUser(int id) {
	
	return false;
}
@Override
public User registerUser(User user) {
	
	return userRepository.save(user);
}
 
@Override
public User getUser(Long id) {
	Optional<User> user = userRepository.findById(id);
	if(user.isPresent()) {
		return user.get();
	}
	else {
		return null;
	}

}
	
}	


		
		
		
		
