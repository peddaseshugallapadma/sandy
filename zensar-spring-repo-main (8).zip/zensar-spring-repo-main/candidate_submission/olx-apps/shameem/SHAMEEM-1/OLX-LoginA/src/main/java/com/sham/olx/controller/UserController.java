package com.sham.olx.controller;


import java.util.List;import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.sham.olx.model.User;
import com.sham.olx.service.UserService;
import com.sham.olx.repository.UserRepository;
@RestController
@RequestMapping("/users")
public class UserController {@Autowired
UserService userService; @GetMapping
public ResponseEntity<List<User>> getAllUsers(){ return new ResponseEntity<>(userService.getAllUsers(),HttpStatus.OK);
}
@PostMapping("/authenticate")
public String loginUser(@RequestBody User user) {
return userService.loginUser(user.getUsername(), user.getPassword());}
@GetMapping("/{id}")
public User getUser(@PathVariable int id) {
System.out.println(id);
return userService.getUser(id);
}
public User registerUser(@RequestBody User user) {
return userService.registerUser(user);
}
public boolean logoutUser(int id) {
return false;
}
}

