package com.sham.olx;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(" com.sham.olx")
public class UserLoginAApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserLoginAApplication.class, args);
	}

}
