package com.jyothi.olx.service;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jyothi.olx.model.User;
import com.jyothi.olx.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    UserRepository userRepository;
 
      Map<Integer,User> userList=new HashMap<>();
 
        public List<User> getAllUsers() {
            List<User> userslist =new ArrayList<>();
               for(User u : userList.values()) {
                   userslist.add(u);
               }
            return userslist;
 
}
public String loginUser(String username, String password) {
    User user = userRepository.findUserByUsernameAndPassword(username, password);
    if(user !=null) {
        return username;    
    }
    else
    {
        return null;
    }
}
public boolean logoutUser(int id) {

    return false;
}
public User registerUser(User user) {

    return userRepository.save(user);
}

public User getUser(Long id) {
    Optional<User> user = userRepository.findById(id);
    if(user.isPresent()) {
        return user.get();
    }
    else {
        return null;
    }
 
}

}    

