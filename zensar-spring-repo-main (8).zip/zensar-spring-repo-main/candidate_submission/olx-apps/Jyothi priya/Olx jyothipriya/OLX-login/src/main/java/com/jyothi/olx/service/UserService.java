package com.jyothi.olx.service;
import java.util.List;

import com.jyothi.olx.model.User;


 
 
public interface UserService {

       public List<User> getAllUsers();
 
       //public User createUser (Long id);
 
    public String loginUser(String username , String password);

    public User registerUser(User user);

    public User getUser(Long id);

    public boolean logoutUser(int id);
 
    

 
       
 
       
}