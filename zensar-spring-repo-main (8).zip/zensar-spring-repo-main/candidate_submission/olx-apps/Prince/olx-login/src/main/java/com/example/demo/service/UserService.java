package com.example.demo.service;

import com.example.demo.modul.User;
import com.example.demo.util.UserNotFoundException;

public interface UserService {
	// 1. Logins a user
		public String loginUser(String userName, String password) throws UserNotFoundException; // POST

		// Logout a user
		public boolean logoutUser(Integer id); // DELETE

		// 3. Registers an user
		public User registerUser(User user); // POST

		// 4. Returns user by id
		public User getUser(Integer id); // GET
}
