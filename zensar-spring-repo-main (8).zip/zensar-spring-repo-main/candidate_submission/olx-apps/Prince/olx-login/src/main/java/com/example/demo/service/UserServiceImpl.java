package com.example.demo.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.example.demo.modul.User;
import com.example.demo.repository.UserRepository;
import com.example.demo.util.UserNotFoundException;



@Service
public class UserServiceImpl implements UserService {
	@Autowired
	UserRepository userRepository;
	

	// add user
		@Override
		public User registerUser(User user) {
			
			return userRepository.save(user);
		}
	//Returns user by id
		@Override
		public User getUser(Integer id) {
			Optional<User> user = userRepository.findById(id);
			if (user.isPresent()) {
				return user.get();
			} else {
				return null;
			}
		}
	// Logout a user
		@Override
		public boolean logoutUser(Integer id) {
			return false;
		}
		@Override
		public String loginUser(String userName, String password) throws UserNotFoundException {
			User user = userRepository.findUserByUsernameAndPassword(userName, password);
			if (user != null) {
				
				return userName;
			} else {
				throw new UserNotFoundException("User is not Register : "+userName);
			}
		}
}
