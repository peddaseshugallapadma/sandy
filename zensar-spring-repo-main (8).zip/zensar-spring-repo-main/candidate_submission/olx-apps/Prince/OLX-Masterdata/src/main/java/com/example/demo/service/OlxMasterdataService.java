package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.AdvStatus;
import com.example.demo.entity.Categories;



public interface OlxMasterdataService {
	public List<AdvStatus> getAllAdvStatus();

	public List<Categories> getAllCategories();

	public void addAdvertiseStatus();

	public void addCategories();
}
