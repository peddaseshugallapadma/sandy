package com.example.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;




@Entity
@Table(name = "CATEGORIES")
public class Categories {
	@Id
	private int id;
	@Column
	private String name;
	@JsonIgnore
	@Column
	private String description;
	
	Categories() {
	}

	public Categories(int i, String name, String desc) {
		// TODO Auto-generated constructor stub
		id = i;
		this.name = name;
		description = desc;
	}
	
	@Override
	public String toString() {
		return "Categories [id=" + id + ", name=" + name + ", description=" + description + "]";
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
}
