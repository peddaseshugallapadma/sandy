package com.prati.olx.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prati.olx.model.User;
import com.prati.olx.reposetery.UserRepository;
@Service
public class UserServiceImpl implements UserService{

	
	@Autowired
	UserRepository uService;
	
	@Override
	public User Regitration(User u)
	{
		return uService.save(u);
	}
	@Override
	public List<User> fetchAllUser()
	{
		return uService.findAll();
	}
	
	@Override
	public void deleteById(Integer uid)
	{
		uService.deleteById(uid);
	}
	
	@Override
	public Boolean logout(User u)
	{
		User uS=uService.findByUnameAndPassword(u.getUname(),u.getPassword());
		if(uS !=null)
		{
			uService.delete(uS);
			return true;
		}
		return false;
	}
	
	
	
	@Override
	public String login(User u )
	{
		User uServices=uService.findByUnameAndPassword(u.getUname(),u.getPassword());
		if(uServices != null)
		{
			return "your succesfully login";
		}
		else
		{
			return "Username and password is incorrect";
		}
	}
	
	
	
}
