package com.prati.olx.service;

import java.util.List;

import com.prati.olx.model.User;

public interface UserService {
	
	public User Regitration(User u);
	public List<User> fetchAllUser();
	public Boolean logout(User u);
	public String login(User u );
	public void deleteById(Integer uid);
	
}
