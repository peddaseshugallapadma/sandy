package com.prati.olx.reposetery;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.prati.olx.model.User;

public interface UserRepository extends JpaRepository<User,Integer>{

	User findByUnameAndPassword(String uname,String password);
	User findByUid(Integer uid);
}
