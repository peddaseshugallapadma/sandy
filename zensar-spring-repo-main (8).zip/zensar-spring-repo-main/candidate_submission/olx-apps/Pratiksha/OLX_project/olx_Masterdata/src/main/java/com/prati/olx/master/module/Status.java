package com.prati.olx.master.module;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;
@Data
@Entity
@Table(name="adv_status")

public class Status {
	
		@Id
		public int id;
		@Column
		public String status;
		

}
