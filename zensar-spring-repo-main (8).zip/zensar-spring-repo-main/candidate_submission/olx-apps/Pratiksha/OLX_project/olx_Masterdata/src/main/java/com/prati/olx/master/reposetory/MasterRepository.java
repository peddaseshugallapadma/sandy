package com.prati.olx.master.reposetory;

import org.springframework.data.jpa.repository.JpaRepository;

import com.prati.olx.master.module.Categories;


public interface MasterRepository extends JpaRepository<Categories,Integer>{

}
