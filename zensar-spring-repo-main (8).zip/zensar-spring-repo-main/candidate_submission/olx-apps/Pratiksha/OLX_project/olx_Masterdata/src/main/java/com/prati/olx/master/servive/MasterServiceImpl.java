package com.prati.olx.master.servive;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prati.olx.master.module.Categories;
import com.prati.olx.master.module.Status;
import com.prati.olx.master.reposetory.MasterRepository;

@Service
public class MasterServiceImpl implements MasterService {
	
	@Autowired
    MasterRepository cService;
	
	@Override
	public Categories addCat(Categories c)
	{
		return cService.save(c);
	}
	
	@Override
	public List<Categories> fetchAllCat()
	{
		return cService.findAll();
	}

		
}
