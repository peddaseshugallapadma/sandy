package com.prati.olx.master.reposetory;

import org.springframework.data.jpa.repository.JpaRepository;

import com.prati.olx.master.module.Status;


public interface StatusRepository extends JpaRepository<Status,Integer>{


}
