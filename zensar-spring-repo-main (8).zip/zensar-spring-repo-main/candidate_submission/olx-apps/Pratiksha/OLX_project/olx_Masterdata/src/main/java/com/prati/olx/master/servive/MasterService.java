package com.prati.olx.master.servive;

import java.util.List;

import com.prati.olx.master.module.Categories;
import com.prati.olx.master.module.Status;

public interface MasterService {
	public Categories addCat(Categories c);
	public List<Categories> fetchAllCat();
	
	
}
