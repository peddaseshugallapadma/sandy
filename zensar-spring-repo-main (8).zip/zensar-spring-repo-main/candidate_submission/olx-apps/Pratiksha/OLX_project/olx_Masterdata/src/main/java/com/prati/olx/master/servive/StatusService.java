package com.prati.olx.master.servive;

import java.util.List;

import com.prati.olx.master.module.Status;

public interface StatusService {
	public Status addStatus(Status c);
	public List<Status> findStatus();

}
