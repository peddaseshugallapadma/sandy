package com.prati.olx.master.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.prati.olx.master.module.Categories;
import com.prati.olx.master.servive.MasterService;

@RestController
@RequestMapping("/categories")
public class MasterController {
	@Autowired
    MasterService mService;
	
@PostMapping
public ResponseEntity<Categories> addCat(@RequestBody Categories u){
	return new ResponseEntity<>(mService.addCat(u), HttpStatus.CREATED);
}

@GetMapping
public ResponseEntity<List<Categories>> getAllCat(){
	return new ResponseEntity<>(mService.fetchAllCat(),HttpStatus.OK);
}


}
