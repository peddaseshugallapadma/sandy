package com.prati.olx.master.module;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name="categories")
public class Categories 
{

	@Id
	public int id;
	@Column
	public String name;
	@Column
	public String description;
	
	
}
