package com.prati.olx.master.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.prati.olx.master.module.Categories;
import com.prati.olx.master.module.Status;
import com.prati.olx.master.servive.StatusService;

@RestController
@RequestMapping("/status")
public class StstusController {


	@Autowired
    StatusService sService;
	
@PostMapping
public ResponseEntity<Status> addStatus(@RequestBody Status u){
	return new ResponseEntity<>(sService.addStatus(u), HttpStatus.CREATED);
}

@GetMapping
public ResponseEntity<List<Status>> getAllStatus(){
	return new ResponseEntity<>(sService.findStatus(),HttpStatus.OK);
}


}


