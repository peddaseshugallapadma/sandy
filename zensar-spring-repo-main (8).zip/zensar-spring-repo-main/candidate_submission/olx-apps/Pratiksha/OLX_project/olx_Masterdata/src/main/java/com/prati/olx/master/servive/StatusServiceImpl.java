package com.prati.olx.master.servive;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prati.olx.master.module.Status;
import com.prati.olx.master.reposetory.StatusRepository;
@Service
public class StatusServiceImpl implements StatusService{
	@Autowired
    StatusRepository sService;
	

	@Override
	public Status addStatus(Status s) {
		// TODO Auto-generated method stub
		return sService.save(s);
		}

	@Override
	public List<Status> findStatus() {
		// TODO Auto-generated method stub
		return sService.findAll();
		}
}
