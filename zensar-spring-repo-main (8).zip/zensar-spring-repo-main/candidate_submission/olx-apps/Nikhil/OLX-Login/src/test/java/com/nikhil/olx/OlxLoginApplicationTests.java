package com.nikhil.olx;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OlxLoginApplicationTests {

	@Test
	void contextLoads() {
	}

}
