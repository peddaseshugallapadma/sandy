
	
	
	package com.bks.repository;

	import org.springframework.data.jpa.repository.JpaRepository;

import com.bks.exmaple.module.Order;


	public interface OrderRepository extends JpaRepository<Order, Integer> {

	}




