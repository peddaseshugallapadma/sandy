package com.bks.exmaple.module;

import java.sql.Date;


import javax.persistence.*;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

//import org.springframework.boot.autoconfigure.domain.EntityScan;





@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="orders")


public class Order {

	@Id
	private Long oid;
	
	@Column
	private String oname;
	
	@Column
	private String detail;
	
	@Column
	private Date odate;
	
	@Column
	private Double price;

	public void setOname(String name) {
		
		this.oname=name;
		
		
	}
	
	

}


