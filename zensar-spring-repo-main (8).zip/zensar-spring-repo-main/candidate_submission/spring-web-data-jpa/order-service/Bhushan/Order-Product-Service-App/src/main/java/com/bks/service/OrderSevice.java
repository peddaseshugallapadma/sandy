package com.bks.service;

import java.util.List;

import com.bks.exmaple.module.Order;

public interface OrderSevice {

	
	
	public Order getOrderById(Long Id);
	
	public Order addOrder(Order o);
	
	public Order updateOrder(Long oid, Order o);
	
	public Order updateOrderName(Long oid, String oname);
	
	public Order deleteOrder(Long oid);
	
   public List<Order> fetchAllOrder();
}

