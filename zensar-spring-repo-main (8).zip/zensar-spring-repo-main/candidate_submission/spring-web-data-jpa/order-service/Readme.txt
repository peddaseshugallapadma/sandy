
Create an microservice as a order-service
This will have all the CRUD operation as below:
GET :/orders - Fetch all orders
2. GET: /orders/1 - to fetch order by id
3. POST:/orders - to add new order
4. PUT: /orders/1 - to update order
5. PATCH:/orders/1 - to update one field
6. DELETE/orders/1 - to delete a specific order

Please also include the data-jpa and mysql dependency.
You need to connect to Mysql and create a db for the same.
Please create a service class always.
