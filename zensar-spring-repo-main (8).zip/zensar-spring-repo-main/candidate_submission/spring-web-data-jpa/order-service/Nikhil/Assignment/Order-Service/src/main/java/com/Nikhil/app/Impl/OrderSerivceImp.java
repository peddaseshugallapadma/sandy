package com.nikhil.app.Impl;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nikhil.app.model.Order;
import com.nikhil.app.repositary.OrderRepositary;
@Service

public class OrderSerivceImp implements OrderService{
	
	@Autowired
	OrderRepositary orderrepositroy;

	@Override
	public List<Order> getAllOrders() {
		// TODO Auto-generated method stub
		return orderrepositroy.findAll();
	}

	@Override
	public Order orderById(Integer orderId) {
		// TODO Auto-generated method stub
		return orderrepositroy.findById(orderId).get();
	}

	@Override
	public Order addorder(Order order) {
		// TODO Auto-generated method stub
		return orderrepositroy.save(order);
	}

	@Override
	public Order updateOrder(Integer orderId, Order order) {
		// TODO Auto-generated method stub
	    if(order.getOrderId().equals(orderId)) {
		return orderrepositroy.save(order);
	    }else {
	    	return new Order();
	    }
	}

	@Override
	public Order updateOrderByName(Integer orderId, String Name) {
		Order order=new Order();
		if(orderrepositroy.findById(orderId).get().equals(order.getOrderId())) {
			order.setName(Name);	
		}
		return order;	}

	@Override
	public void deletingOrder(Order order) {
		// TODO Auto-generated method stub
		orderrepositroy.delete(order);;
	}

	

	
	
	
	
	
	
	
}
