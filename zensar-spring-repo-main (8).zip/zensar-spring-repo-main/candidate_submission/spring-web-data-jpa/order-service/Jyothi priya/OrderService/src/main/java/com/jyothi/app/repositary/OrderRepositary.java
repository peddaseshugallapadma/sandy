package com.jyothi.app.repositary;
import org.springframework.data.jpa.repository.JpaRepository;

import com.jyothi.app.model.Order;

public interface OrderRepositary extends JpaRepository<Order,Integer>{


}