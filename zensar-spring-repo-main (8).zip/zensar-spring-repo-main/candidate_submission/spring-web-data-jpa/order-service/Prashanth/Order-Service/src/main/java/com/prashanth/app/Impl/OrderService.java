package com.prashanth.app.Impl;
import java.util.List;


import com.prashanth.app.model.Order;


public interface OrderService {

	    public List<Order> getAllOrders();
	    
	    public Order orderById(Integer orderId);
	    
	    public Order addorder(Order order);
	    
       public Order updateOrder(Integer orderId,Order order);
    
	    public Order updateOrderByName(Integer orderId,String Name);
	    
	    public void deletingOrder(Order orderId);
	    
	    
	    
	    
}
