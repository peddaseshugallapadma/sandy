package com.example.service;

import java.util.List;

import com.example.demo.module.Order;





public interface OrderService {
public List<Order> getOrders(String orderId);
public Order getOrderById(Long orderId);
public Order addOrder(Order order);
	
}
