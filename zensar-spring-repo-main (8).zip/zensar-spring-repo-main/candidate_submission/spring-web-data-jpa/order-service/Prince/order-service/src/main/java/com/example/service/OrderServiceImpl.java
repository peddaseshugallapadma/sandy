package com.example.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.module.Order;
import com.example.repo.OrderRepositary;



@Service
public class OrderServiceImpl implements OrderService {
	//Map<Long, Order> orderRepositary = new HashMap<>();
	@Autowired
	OrderRepositary orderRepositary;
	
	
	@Override
	public List<Order> getOrders(String OrderId) {
		return orderRepositary.findAll();
	}
	
	@Override
	public Order getOrderById(Long orderId) {
		return orderRepositary.getById(orderId);
	}
	
	@Override
	public Order addOrder(Order order) {
		//orderRepositary.put(order.getOid(), order);
		return orderRepositary.save(order);
	}
}
