package com.bharath.app.repositary;

import org.springframework.data.jpa.repository.JpaRepository;

import com.prashanth.app.model.Order;

public interface OrderRepositary extends JpaRepository<Order,Integer>{



}
