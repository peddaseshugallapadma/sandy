package com.aisha.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderServiceApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
