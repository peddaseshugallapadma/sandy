package com.sobha.app.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name ="orders")
public class Order {
     
	  @Id
	  private Integer orderId;
	  
	  @Column
	  private String name;
       
	  @Column
      private String descripion;
      
	  @Column
      private Double ammount;
       
	  @Column
      private Date dateoforder;

}
