package com.example.demo.model;

import java.sql.Date;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor

public class Order {

	  
	  private Integer orderId;

	  
	  private String orderName;


      private String description;


      private Double amount;


      private Date dateofOrder;

}
 

