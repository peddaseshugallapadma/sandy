package com.girish.app.repositary;

import org.springframework.data.jpa.repository.JpaRepository;

import com.girish.app.model.Order;

public interface OrderRepositary extends JpaRepository<Order,Integer>{



}
