package com.girish.app.model;

import java.util.Date;

import javax.persistence.*;




@Entity
@Table(name ="orders")
public class Order {
     
	  @Id
	  private Integer orderId;
	  
	  @Column
	  private String name;
       
	  @Column
      private String descripion;
      
	  @Column
      private Double ammount;
       
	  @Column
      private Date dateoforder;

		public Order()
		{
			
		}
		
		public Order(Integer orderId, String name, String descripion, Double ammount, Date dateoforder) {
			super();
			this.orderId = orderId;
			this.name = name;
			this.descripion = descripion;
			this.ammount = ammount;
			this.dateoforder = dateoforder;
		}
     
	  public Integer getOrderId() {
		return orderId;
	}

	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescripion() {
		return descripion;
	}

	public void setDescripion(String descripion) {
		this.descripion = descripion;
	}

	public Double getAmmount() {
		return ammount;
	}

	public void setAmmount(Double ammount) {
		this.ammount = ammount;
	}

	public Date getDateoforder() {
		return dateoforder;
	}

	public void setDateoforder(Date dateoforder) {
		this.dateoforder = dateoforder;
	

	
	}

		
		@Override
		public String toString() {
			return "Order [orderId=" + orderId + ", name=" + name + ", descripion=" + descripion + ", ammount=" + ammount
					+ ", dateoforder=" + dateoforder + "]";
		}
}
