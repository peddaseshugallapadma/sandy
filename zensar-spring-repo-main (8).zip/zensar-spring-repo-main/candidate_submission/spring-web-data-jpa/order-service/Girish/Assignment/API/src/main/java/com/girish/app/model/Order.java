package com.girish.app.model;

import java.util.Date;

import lombok.Data;

@Data
public class Order {
	
	  private Integer orderId;
	  
	  
	  private String name;
       
	  
      private String descripion;
      
	  
      private Double ammount;
       
	  
      private Date dateoforder;
	
	 public Integer getOrderId() {
		return orderId;
	}


	public void setOrderId(Integer orderId) {
		this.orderId = orderId;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getDescripion() {
		return descripion;
	}


	public void setDescripion(String descripion) {
		this.descripion = descripion;
	}


	public Double getAmmount() {
		return ammount;
	}


	public void setAmmount(Double ammount) {
		this.ammount = ammount;
	}


	public Date getDateoforder() {
		return dateoforder;
	}


	public void setDateoforder(Date dateoforder) {
		this.dateoforder = dateoforder;
	}


	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", name=" + name + ", descripion=" + descripion + ", ammount=" + ammount
				+ ", dateoforder=" + dateoforder + "]";
	}



}
