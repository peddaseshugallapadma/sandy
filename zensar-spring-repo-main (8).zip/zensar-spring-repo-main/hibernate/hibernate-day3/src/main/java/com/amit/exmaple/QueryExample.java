package com.amit.exmaple;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.amit.exmaple.model.Employee;

import jakarta.persistence.Query;

public class QueryExample {
	
	public static void main(String[] args) {
		
		System.out.println("One to Many Example");
		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
		Session session = sessionFactory.openSession();
		
		Query query = session.createQuery("FROM Employee", Employee.class);
//		query.setParameter("mobileNo", "234243534");
		List<Employee> employees = query.getResultList();
		for(Employee emp: employees) {
			System.out.println(emp);
		}
		session.close();
		sessionFactory.close();
		
	}

}
