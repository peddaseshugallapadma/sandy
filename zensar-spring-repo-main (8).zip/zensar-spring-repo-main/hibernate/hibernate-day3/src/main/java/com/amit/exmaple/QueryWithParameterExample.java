package com.amit.exmaple;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.amit.exmaple.model.Employee;

import jakarta.persistence.Query;

public class QueryWithParameterExample {
	
	private static final String MOBILE_NO = "mobileNo";
	private static final String FETCH_EMPLOYEE_BY_MOBILE_NO = "from Employee e where e.mobileNo = :mobileNo";

	public static void main(String[] args) {
		
		getEmployeeByMobileNo();
		
	}

	private static void getEmployeeByMobileNo() {
		System.out.println("One to Many Example");
		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
		Session session = sessionFactory.openSession();
		
		Query query = session.createQuery(FETCH_EMPLOYEE_BY_MOBILE_NO, Employee.class);
		query.setParameter(MOBILE_NO, "234243534");
		List<Employee> employees = query.getResultList();
		for(Employee emp: employees) {
			System.out.println(emp);
		}
		session.close();
		sessionFactory.close();
	}

}
