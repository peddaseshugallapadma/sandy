package com.amit.exmaple;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import com.amit.exmaple.model.Employee;

import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;

public class CriteriaQueryExample {
	
	public static void main(String[] args) {
		
		System.out.println("Criteria Example");
		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
		Session session = sessionFactory.openSession();
		
		CriteriaBuilder builder = session.getCriteriaBuilder();

        // Count number of employees
        CriteriaQuery<Long> criteriaQuery = builder.createQuery(Long.class);
        Root<Employee> root = criteriaQuery.from(Employee.class);
        criteriaQuery.select(builder.count(root));
        Query<Long> query = session.createQuery(criteriaQuery);
        long count = query.getSingleResult();
        System.out.println("Count = " + count);
        
        
     // mobileNo employees
        CriteriaQuery<Employee> criteriaQuery2 = builder.createQuery(Employee.class);
        Root<Employee> root2 = criteriaQuery2.from(Employee.class);
        Predicate predicateForMobile = builder.equal(root2.get("mobileNo"), "234243534");
        criteriaQuery2.where(predicateForMobile);
        List<Employee> employees = session.createQuery(criteriaQuery2).getResultList();
        for(Employee emp: employees) {
        	System.out.println(emp);
        }
		
		session.close();
		sessionFactory.close();
		
	}

}
