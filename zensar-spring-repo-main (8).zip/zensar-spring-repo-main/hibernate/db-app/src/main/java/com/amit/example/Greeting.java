package com.amit.example;

import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="greetings")
public class Greeting {
	
	@Id
	private int id;
	
	@Column
	private String message;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	public Greeting() {
		
	}
	
	public Greeting(int id, String message) {
		super();
		this.id = id;
		this.message = message;
	}
	@Override
	public int hashCode() {
		return Objects.hash(id, message);
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Greeting other = (Greeting) obj;
		return id == other.id && Objects.equals(message, other.message);
	}
	
	@Override
	public String toString() {
		return "Greeting [id=" + id + ", message=" + message + "]";
	}
	

}
