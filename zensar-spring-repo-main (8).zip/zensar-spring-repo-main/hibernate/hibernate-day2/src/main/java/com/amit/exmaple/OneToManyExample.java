package com.amit.exmaple;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.amit.exmaple.model.Department;
import com.amit.exmaple.model.Employee;

public class OneToManyExample {
	
public static void main(String[] args) {
		
		System.out.println("One to Many Fetch Example");
		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
		Session session = sessionFactory.openSession();
		
		session.beginTransaction();
		
		Department department = session.get(Department.class, new Long(1));
		
		List<Employee> employees = department.getEmployees();
		for(Employee emp: employees) {
			System.out.println(emp);
		}
		
		session.getTransaction().commit();
		session.close();
		sessionFactory.close();
		
	}

}
