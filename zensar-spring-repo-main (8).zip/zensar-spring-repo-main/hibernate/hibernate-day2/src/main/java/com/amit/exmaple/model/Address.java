package com.amit.exmaple.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "address")
public class Address {
	
	@Id
	private Long addressId;
	
	@Column
	private String flatNo;
	
	@Column
	private String soceityName;
	
	@Column
	private String street;
	
	@Column
	private String area;
	
	@Column
	private Long pincode;
	
	@Column
	private String city;
	
	@Column
	private String state;
	
	@Column
	private String country;
	
	@OneToOne
	private Employee employee;
	

}
