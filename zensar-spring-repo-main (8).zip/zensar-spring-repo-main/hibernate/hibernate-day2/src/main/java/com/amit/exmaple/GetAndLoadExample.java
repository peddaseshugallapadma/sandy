package com.amit.exmaple;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.amit.exmaple.model.Employee;


public class GetAndLoadExample {
	
	public static void main(String[] args) {

		System.out.println("Fetch from first level cache Example");
		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
		Session session = sessionFactory.openSession();
		
		
		Employee employee = session.get(Employee.class, new Integer(24));
		System.out.println(employee);
		
		Employee employee1 = session.load(Employee.class, new Integer(24));
		System.out.println(employee1);
		
		session.close();
		sessionFactory.close();

	}

}
