package com.amit.exmaple;

import java.sql.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.amit.exmaple.model.Address;
import com.amit.exmaple.model.Employee;

public class OneToOneSample {
	
public static void main(String[] args) {
		
		System.out.println("One to One Example");
		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
		Session session = sessionFactory.openSession();
		
		session.beginTransaction();
		
		Employee employee = new Employee(1L,"Amit", "Kumar", new Date(2010, 8, 7), "234243534");
		Address address = new Address(1L, "406", "Galaxy", "Dhole Patil Road", "Camp", 411011L, "Pune", "Maharastra", "India", employee);
		session.saveOrUpdate(address);
		session.persist(address);
		session.save(address);
		session.update(address);
		session.merge(address);
		session.getTransaction().commit();
		session.close();
		sessionFactory.close();
		
	}

}
