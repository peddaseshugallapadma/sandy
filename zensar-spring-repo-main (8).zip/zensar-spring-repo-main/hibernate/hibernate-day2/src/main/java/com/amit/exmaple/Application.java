package com.amit.exmaple;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.amit.exmaple.model.Department;
import com.amit.exmaple.model.Employee;

public class Application {
	
	public static void main(String[] args) {
		
		System.out.println("One to Many Example");
		List<Employee> employees = new ArrayList<Employee>();
		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
		Session session = sessionFactory.openSession();
		
		
		session.beginTransaction();
		Employee employee1 = new Employee(1L,"Amit", "Kumar", new Date(122, 8, 7), "234243534");
		session.save(employee1);
		employees.add(employee1);
		
		Employee employee2 = new Employee(2L,"Sujoy", "Kumar", new Date(122, 8, 7), "13423423");
		session.save(employee2);
		employees.add(employee2);
		
		Department department = new Department(1L, "department 1", employees);
		session.save(department);
		session.getTransaction().commit();
		session.close();
		sessionFactory.close();
		
	}

}
