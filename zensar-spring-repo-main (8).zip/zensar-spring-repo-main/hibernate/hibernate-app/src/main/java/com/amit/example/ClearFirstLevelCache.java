package com.amit.example;

import java.sql.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.amit.example.model.Employee;
import com.amit.example.model.Greeting;

public class ClearFirstLevelCache {

	public static void main(String[] args) {

		System.out.println("Transaction Factory Example");
		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
		Session session = sessionFactory.openSession();
		
		session.beginTransaction();
		Greeting greeting = new Greeting(1, "Hello Amit");
		session.save(greeting);
		session.getTransaction().commit();
		
		session.beginTransaction();
		session.evict(greeting);
		Greeting greets = session.get(Greeting.class, new Integer(1));
		System.out.println(greets);
		session.getTransaction().commit();
		
		session.beginTransaction();
		Employee employee = new Employee(1L,"Amit", "Kumar", new Date(2010, 8, 7), "234243534");
		session.save(employee);
		session.getTransaction().commit();
		session.close();
		sessionFactory.close();

	}

}
