package com.amit.example;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.amit.example.model.Employee;
import com.amit.example.model.Greeting;

/**
 * Hello world!
 *
 */
public class App {
	
	public static void main(String[] args) {
		// Register the driver
//		jdbcInsertGreeting();
		System.out.println("Hibernate Example");
		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
//		Greeting greets = session.get(Greeting.class, new Integer(1));
//		System.out.println(greets);
		Employee employee = new Employee(1L,"Amit", "Kumar", new Date(2010, 8, 7), "234243534");
		session.save(employee);
		session.getTransaction().commit();
		session.close();
		sessionFactory.close();
	}

	private static void jdbcInsertGreeting() {
		try {
			System.out.println("JDBC Example");
			Class.forName("com.mysql.cj.jdbc.Driver");
			String url = "jdbc:mysql://localhost:3306/test";
			String userName = "root";
			String password = "root";
			Greeting greeting = new Greeting(4,"All the best");
			Connection con = DriverManager.getConnection(url, userName, password);
			Statement stm = con.createStatement();
			String query = "insert into greetings values("+greeting.getId()+",'"+greeting.getMessage()+"')";
			System.out.println(query);
			int k = stm.executeUpdate(query);
			if (k > 0) {
				System.out.println("Sussfully updated");
			}
			ResultSet rs = stm.executeQuery("Select * from greetings");
			while (rs.next()) {
				System.out.println("ID=" + rs.getInt(1) + "\t Message=" + rs.getString(2));
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
