package com.amit.example;

import java.sql.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.amit.example.model.Employee;
import com.amit.example.model.Meeting;


public class Application {
	
	public static void main(String[] args) {
		
		System.out.println("Many to Many Example");
		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		
		Meeting meeting1 = new Meeting(1L, "Daily Scrum");
		Meeting meeting2 = new Meeting(2L, "Retrospective");
		
		Employee employee1 = new Employee(8L,"Amit", "Kumar", new Date(122, 8, 7), "234243534");
		employee1.getMeetings().add(meeting1);
		employee1.getMeetings().add(meeting2);
		session.save(employee1);
		
		Employee employee2 = new Employee(9L,"Sujoy", "Kumar", new Date(122, 8, 7), "13423423");
		employee2.getMeetings().add(meeting2);
		session.save(employee2);
		
		/*
		 * meeting1.getEmployees().add(employee2);
		 * meeting1.getEmployees().add(employee1);
		 * meeting2.getEmployees().add(employee1);
		 * 
		 * session.save(meeting2); session.save(meeting1);
		 */
		
		session.getTransaction().commit();
		session.close();
		sessionFactory.close();
		
	}

}
