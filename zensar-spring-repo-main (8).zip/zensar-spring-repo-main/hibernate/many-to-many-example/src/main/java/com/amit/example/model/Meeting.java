package com.amit.example.model;

import java.sql.Date;
import java.util.HashSet;
import java.util.Set;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="meetings")
public class Meeting {
	
	@Id
	@GeneratedValue
	private Long meetingId;
	
	@Column
	private String subject;
	
	@Column
	private Date meetingDate;
	
	@ManyToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL, mappedBy = "meetings")
	private Set<Employee> employees = new HashSet<Employee>();
	
	public Meeting(Long meetingId, String subject) {
		this.meetingId = meetingId;
		this.subject = subject;
	}

}
