package com.amit.example.model;

import java.sql.Date;
import java.util.HashSet;
import java.util.Set;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="employeedet")
public class Employee {
	
	@Id
	private Long empId;
	
	@Column
	private String firstName;
	
	@Column
	private String lastName;
	
	@Column
	private Date joiningDate;
	
	@Column
	private String mobileNo;
	
	@ManyToMany(cascade = {CascadeType.ALL})
	@JoinTable(name="employeedet_meeting", 
		joinColumns = {@JoinColumn(name="empId")},
		inverseJoinColumns= {@JoinColumn(name="meetingId")})
	private Set<Meeting> meetings = new HashSet<Meeting>();
	
	public Employee(Long empId, String firstName, String lastName, Date joiningDate, String mobileNo) {
		this.empId = empId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.joiningDate = joiningDate;
		this.mobileNo = mobileNo;
	}

}
