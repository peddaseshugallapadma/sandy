package com.example.demo.sobha;

import java.util.Optional;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="users")

public class User {

@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
private Integer id;
@Column
private String userName;
@Column
private String password;
@Column
private String roles;
@Column
private boolean active;
@Column
private String firstName;
@Column
private String lastName;
@Column
private String email;
@Column
private long phone;
public Optional<User> findById(Integer id2) {
	// TODO Auto-generated method stub
	return null;
}
public User findUserByUsernameAndPassword(String userName2, String password2) {
	// TODO Auto-generated method stub
	return null;
}


}


