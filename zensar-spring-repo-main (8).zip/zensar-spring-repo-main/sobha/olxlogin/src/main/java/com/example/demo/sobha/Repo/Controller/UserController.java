package com.example.demo.sobha.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.sobha.User;
import com.example.demo.sobha.service.Service;
@RestController
@RequestMapping("/users")

public class UserController {
	@Autowired
	Service userservice;
	
	//Registers an user
	@PostMapping
	public User registerUser(@RequestBody User user) {
		//System.out.println(user);
		return userservice.registerUser(user);
	}
	@GetMapping("/{id}")
	public User getUser(@PathVariable Integer id) 
	{
		//System.out.println(id);
		return userservice.getUser(id);
	}
	public boolean logoutUser(Integer id) { 
			return false;
		}
	@PostMapping("/authenticate")
	public String loginUser(@RequestParam String userName, @RequestParam String password)// throws UserNotFoundException 
	{
		System.out.println(userName);
		System.out.println("Loginin");
		return userservice.loginUser(userName, password);
	}
}



