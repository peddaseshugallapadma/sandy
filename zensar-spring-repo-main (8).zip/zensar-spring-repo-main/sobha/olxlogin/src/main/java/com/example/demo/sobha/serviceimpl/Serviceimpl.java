package com.example.demo.sobha.serviceimpl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.sobha.User;
import com.example.demo.sobha.Repo.Repository;
import com.example.demo.sobha.service.Service;

public abstract class Serviceimpl implements Service {
	@Autowired
	User userRepository;

	

	// add user
		@Override
		public User registerUser(User user) {
			
		
				return Repository.save(user);
		}

	//Returns user by id
		@Override
		public User getUser(Integer id) {
			Optional<User> user = userRepository.findById(id);
			if (user.isPresent()) {
				return user.get();
			} else {
				return null;
			}
		}
	// Logout a user
		@Override
		public boolean logoutUser(Integer id) {
			return false;
		}
		
	//login user
		@Override
		public String loginUser(String userName, String password){// throws UserNotFoundException {
			User user = userRepository.findUserByUsernameAndPassword(userName, password);
			if (user != null) {
				
				return userName;
			} else {
																																																																						//throw new UserNotFoundException("User is not Register : "+userName);
				return null;
			}
		}
}

	


