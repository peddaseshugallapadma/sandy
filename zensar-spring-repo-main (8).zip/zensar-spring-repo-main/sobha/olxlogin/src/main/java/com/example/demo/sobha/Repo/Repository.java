package com.example.demo.sobha.Repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;



import com.example.demo.sobha.User;
public interface Repository extends JpaRepository<User, Integer> {
	@Query(value = "SELECT * from users where user_name=? and password=?", nativeQuery = true)
	User findUserByUsernameAndPassword(String username, String password);
	

}
