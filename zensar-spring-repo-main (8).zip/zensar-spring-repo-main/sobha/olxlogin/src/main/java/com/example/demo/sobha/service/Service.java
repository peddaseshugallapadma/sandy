package com.example.demo.sobha.service;

import com.example.demo.sobha.User;

public interface Service {
		
		public String loginUser(String userName, String password);																																										// throws UserNotFoundException; // POST

		
		public boolean logoutUser(Integer id); // DELETE

		
		public User registerUser(User user); // POST

		
		public User getUser(Integer id); // GET
}


