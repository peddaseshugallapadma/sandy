package com.amit.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestTemplateEmployeeConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
