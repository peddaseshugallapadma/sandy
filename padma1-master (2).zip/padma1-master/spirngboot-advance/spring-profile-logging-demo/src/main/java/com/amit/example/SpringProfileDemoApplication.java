package com.amit.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringProfileDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringProfileDemoApplication.class, args);
	}

}
